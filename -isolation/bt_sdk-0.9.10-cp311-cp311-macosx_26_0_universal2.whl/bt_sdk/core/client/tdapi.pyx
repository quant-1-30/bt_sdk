# cython: language_level=3

import asyncio
import msgspec
import threading
from contextlib import contextmanager

from bt_sdk.core.protocol import Event
from bt_sdk.core.client.util cimport fast_uuid4_bytes
from bt_sdk.core.client.async_client cimport AsyncStreamClient


cdef class TdApi:
    """
    # How to implement a tradeApi:
    ---
    ## Basics
    A tradeApi should satisfies:
    * this class should be thread-safe:
        * all methods should be thread-safe
        * no mutable shared properties between objects.
    * all methods should be non-blocked
    * satisfies all requirements written in docstring for every method and callbacks.
    * automatically reconnect if connection lost.

    All the XxxData passed to callback should be constant, which means that
        the object should not be modified after passing to on_xxxx.
    So if you use a cache to store reference of data, use copy.copy to create a new object
    before passing that data into on_xxxx
    """
    
    def __init__(self, 
                    bytes client_id, 
                    tuple addr=("127.0.0.1", 9999), 
                    int timeout=5):
        self.client_id = client_id
        self.async_client = AsyncStreamClient(addr, timeout)

        try:
            loop = asyncio.get_running_loop()
            self.async_client.attach_loop(loop, is_background=False)
        except RuntimeError:
            loop = asyncio.new_event_loop()
         
            self._loop_thread = threading.Thread(
                target=self._run_loop_thread, 
                args=(loop,), 
                daemon=True,
                name="TdApi-Loop"
            )
            self._loop_thread.start()
            self.async_client.attach_loop(loop, is_background=True)

    cdef void _run_loop_thread(self, loop):
            asyncio.set_event_loop(loop)
            loop.run_forever()

    cdef object _send_request(self, int topic, bytes experiment_id=b'', object body={}, int sub_topic=-1):
            cdef bytes req_id = fast_uuid4_bytes()
            cdef object event = Event(
                topic=topic, 
                body=body, 
                experiment_id=experiment_id,
                sub_topic=sub_topic
            )
            return self.async_client.run(req_id, event)

# --------------------------------------------------------------- Ray Async Actor --------------------------------------------------------

    async def register_async(self, object body):
        fut = self._send_request(BrokerTopic.Register, experiment_id=b'', body=body)
        return await fut

    async def set_cash_async(self, bytes experiment_id, object body):
        fut = self._send_request(BrokerTopic.SetCash, experiment_id=experiment_id, body=body)
        return await fut

    async def getvalue_async(self, bytes experiment_id, int topic):
        fut = self._send_request(BrokerTopic.GetValue, experiment_id=experiment_id, body={}, sub_topic=topic)
        return await fut

    async def subscribe_async(self, bytes experiment_id, int topic, object body):
        fut = self._send_request(BrokerTopic.Subscribe, experiment_id=experiment_id, body=body, sub_topic=topic)
        return await fut

    async def submit_async(self, bytes experiment_id, object body):
        fut = self._send_request(BrokerTopic.Submit, experiment_id=experiment_id, body=body)
        return await fut

    async def on_dt_over_async(self, bytes experiment_id, object body):
        fut = self._send_request(BrokerTopic.DayOver, experiment_id=experiment_id, body=body)
        return await fut

# --------------------------------------------------------------- Sync and Local --------------------------------------------------------

    cpdef object register(self, object body):
        fut = self._send_request(topic=BrokerTopic.Register, experiment_id=b'', body=body)
        return fut.result()

    cpdef object set_cash(self, bytes experiment_id, object body): 
        fut = self._send_request(topic=BrokerTopic.SetCash, experiment_id=experiment_id, body=body)
        return fut.result()

    cpdef object getvalue(self, bytes experiment_id, int topic):
        fut = self._send_request(topic=BrokerTopic.GetValue, experiment_id=experiment_id, body={}, sub_topic=topic)
        return fut.result()
    
    cpdef object subscribe(self, bytes experiment_id, int topic, object body):
        fut = self._send_request(topic=BrokerTopic.Subscribe, experiment_id=experiment_id, body=body, sub_topic=topic)
        return fut.result()
    
    cpdef object submit(self, bytes experiment_id, object body):
        fut = self._send_request(topic=BrokerTopic.Submit, experiment_id=experiment_id, body=body)
        return fut.result()
    
    cpdef object on_dt_over(self, bytes experiment_id, object body):
        fut = self._send_request(topic=BrokerTopic.DayOver, experiment_id=experiment_id, body=body)
        return fut.result()
    
    cpdef void disconnect(self):
        self.async_client.close()
